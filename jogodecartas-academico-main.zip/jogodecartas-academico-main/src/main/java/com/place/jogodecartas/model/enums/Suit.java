package com.place.jogodecartas.model.enums;

public enum Suit {
    HEARTS, DIAMONDS, CLUBS, SPADES
}
