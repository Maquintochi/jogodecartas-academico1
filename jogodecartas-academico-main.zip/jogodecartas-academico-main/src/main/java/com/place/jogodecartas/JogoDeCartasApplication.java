package com.place.jogodecartas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JogoDeCartasApplication {
    public static void main(String[] args) {
        SpringApplication.run(JogoDeCartasApplication.class, args);
    }
}
